echo running...
timeout 60 php ltc.php && sleep 300
echo -en '
'
sudo ./new1.sh