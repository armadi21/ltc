echo running...
timeout 330 php ltc.php && sleep 1
echo -en '
'
sudo ./new1.sh