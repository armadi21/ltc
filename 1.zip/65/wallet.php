<?php

//* @SCRIPT AUTO PAYOUT BITCOIN
//* @AKBAR FEAT IPKZONE ( IDDANT )
//* @TEAM : CRYPTO - TUYUL.CO.ID

date_default_timezone_set('Asia/Jakarta');
error_reporting(true);
set_time_limit(0);
ini_set('memory_limit', '-1');
ini_set('output_buffering',0); 
ini_set('request_order', 'GP');
ini_set('variables_order','EGPCS');
ini_set('max_execution_time','-1');

// INPUT YOUR WALLET
$argv[1] = "M8zEu6DpUXaSsPLvGcycaUncWNZNqQ5AY5";
?>